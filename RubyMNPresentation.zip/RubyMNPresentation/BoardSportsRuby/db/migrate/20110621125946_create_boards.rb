class CreateBoards < ActiveRecord::Migration
  def self.up
    create_table :boards do |t|
      t.string :board_name
      t.text :description
      t.integer :board_length

      t.timestamps
    end
  end

  def self.down
    drop_table :boards
  end
end
