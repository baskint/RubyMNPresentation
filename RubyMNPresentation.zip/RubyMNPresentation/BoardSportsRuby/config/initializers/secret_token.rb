# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
BoardSports::Application.config.secret_token = '69aaed6425ff0529eb2d5f754f728d5c4e456550ce21657bb96d0a342d30ef8a17921d787f2480571b4d8512ae0b3b1f814c2aad6c6d9d67e0f412b425eada2d'
