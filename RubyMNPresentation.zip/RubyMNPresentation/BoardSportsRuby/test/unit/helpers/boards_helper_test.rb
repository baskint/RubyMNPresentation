require 'test_helper'

class BoardsHelperTest < ActionView::TestCase
end
