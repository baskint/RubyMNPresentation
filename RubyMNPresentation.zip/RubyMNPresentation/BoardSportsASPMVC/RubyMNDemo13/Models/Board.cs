﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RubyMNDemo13.Models
{
    public class Board
    {
        public int Id { get; set; }

        public string BoardName { get; set; }
        public string Description { get; set; }
        public short Length { get; set; }

    }
}